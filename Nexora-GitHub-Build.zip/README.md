# Nexora

Nexora is a Xeno-inspired desktop GUI demo built with Electron, HTML, CSS, and JavaScript.

## Build a Windows .exe with GitHub Actions

1. Create a GitHub repository and upload all files in this folder, including `.github/workflows/build-windows.yml`.
2. In the repository, open **Actions**.
3. Select **Build Nexora for Windows**.
4. Click **Run workflow**, then click the green **Run workflow** button.
5. Wait for the workflow to finish successfully.
6. Open the completed workflow run and download the **Nexora-Windows-Installer** artifact.
7. Extract the downloaded artifact ZIP. It contains the Nexora Windows installer `.exe`.

You can also create and push a tag such as `v1.0.0` to run the workflow on a release tag. The current workflow uploads an artifact; it does not automatically publish a GitHub Release.

## Local development

```bash
npm install
npm start
```

## Safety / scope

This is a GUI and safe demo runner. It does not inject into Roblox, execute arbitrary Luau in the Roblox client, or bypass Roblox security protections. The demo runner only supports simple `print("text")` and `help()` commands.
