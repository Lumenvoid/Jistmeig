const { contextBridge } = require("electron");

// Keep the renderer isolated from Node.js and the operating system.
contextBridge.exposeInMainWorld("nexora", {
  appName: "Nexora",
  version: "1.0.0"
});
